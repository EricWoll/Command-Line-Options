# Command-Line-Options
A library making it easier to create small command-line option pickers

## Libraries used
- keyboard
- pytest
